const express = require('express');
const mongoose = require('mongoose');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// MongoDB Connection
const MONGO_URI = process.env.MONGO_URI || 'mongodb://localhost:27017/travel_mate';
mongoose.connect(MONGO_URI)
  .then(() => console.log('Connected to MongoDB database successfully'))
  .catch(err => console.error('MongoDB connection error:', err));

// MongoDB Schemas & Models
const routeSchema = new mongoose.Schema({
  origin: { type: String, required: true, trim: true },
  destination: { type: String, required: true, trim: true },
  mode: { type: String, required: true, trim: true },
  distance: { type: Number, required: true },
  duration: { type: Number, required: true },
  fare: { type: Number, required: true },
  safety: { type: Number, default: 8.0 },
  accessibility: { type: Number, default: 8.0 },
  lighting: { type: Number, default: 8.0 },
  activity: { type: Number, default: 8.0 },
  walk: { type: Number, default: 0.5 },
  stepFree: { type: Boolean, default: false },
  departures: [String],
  notes: { type: String, trim: true }
}, { timestamps: true });

const reportSchema = new mongoose.Schema({
  location: { type: String, required: true, trim: true },
  type: { type: String, required: true },
  severity: { type: String, enum: ['low', 'medium', 'high'], default: 'medium' },
  description: { type: String, required: true, trim: true }
}, { timestamps: true });

const Route = mongoose.model('Route', routeSchema);
const Report = mongoose.model('Report', reportSchema);

// Seed initial demo routes if collection is empty
async function seedDB() {
  const count = await Route.countDocuments();
  if (count === 0) {
    await Route.insertMany([
      { origin: "Chennai Central", destination: "Guindy", mode: "Suburban train", distance: 12, duration: 24, fare: 10, safety: 8.7, accessibility: 7.5, lighting: 8.5, walk: 0.6, stepFree: false, departures: ["08:10", "08:30", "08:50", "09:10"], notes: "Frequent suburban connection." },
      { origin: "Chennai Central", destination: "Guindy", mode: "Bus", distance: 13.5, duration: 42, fare: 15, safety: 8.2, accessibility: 8.4, lighting: 8.1, walk: 0.4, stepFree: true, departures: ["08:00", "08:30", "09:00"], notes: "Lower walk distance with accessible boarding." },
      { origin: "Chennai Central", destination: "Tambaram", mode: "Suburban train", distance: 27, duration: 52, fare: 15, safety: 8.5, accessibility: 7.2, lighting: 8.1, walk: 0.7, stepFree: false, departures: ["08:05", "08:25", "08:45"], notes: "Frequent suburban corridor." },
      { origin: "Chennai Central", destination: "Egmore", mode: "Metro", distance: 3.8, duration: 12, fare: 20, safety: 9.0, accessibility: 9.1, lighting: 9.0, walk: 0.3, stepFree: true, departures: ["08:00", "08:10", "08:20"], notes: "Step-free metro interchange." }
    ]);
    console.log('Seed routes populated in MongoDB.');
  }
}
mongoose.connection.once('open', seedDB);

// API Routes
app.get('/api/routes', async (req, res) => {
  try {
    const routes = await Route.find().sort({ createdAt: -1 });
    res.json(routes);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch routes' });
  }
});

app.post('/api/routes', async (req, res) => {
  try {
    const newRoute = new Route(req.body);
    const savedRoute = await newRoute.save();
    res.status(201).json(savedRoute);
  } catch (err) {
    res.status(400).json({ error: 'Failed to add route', details: err.message });
  }
});

app.get('/api/reports', async (req, res) => {
  try {
    const reports = await Report.find().sort({ createdAt: -1 });
    res.json(reports);
  } catch (err) {
    res.status(500).json({ error: 'Failed to fetch reports' });
  }
});

app.post('/api/reports', async (req, res) => {
  try {
    const newReport = new Report(req.body);
    const savedReport = await newReport.save();
    res.status(201).json(savedReport);
  } catch (err) {
    res.status(400).json({ error: 'Failed to submit report', details: err.message });
  }
});

app.listen(PORT, () => {
  console.log(`🚀 Travel Mate app is live at: http://localhost:${PORT}`);
});
