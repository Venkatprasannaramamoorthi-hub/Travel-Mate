(() => {
"use strict";
const $ = id => document.getElementById(id);
const DAY = new Date().toISOString().slice(0,10);
if($("travel-date")) $("travel-date").value = DAY;

let routesCache = [];
let reportsCache = [];

function toast(msg){
  const t = $("toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toast.timer);
  toast.timer = setTimeout(()=>t.classList.remove("show"), 2800);
}

function esc(s){
  return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}

async function fetchRoutes(){
  try {
    const res = await fetch('/api/routes');
    routesCache = await res.json();
  } catch(err) {
    console.error('Failed to load routes from database:', err);
  }
}

async function fetchReports(){
  try {
    const res = await fetch('/api/reports');
    reportsCache = await res.json();
    renderReports();
  } catch(err) {
    console.error('Failed to load reports from database:', err);
  }
}

function scoreRoute(r, prefs){
  let score = (r.safety || 8) * .34 + (r.accessibility || 8) * .24 + (r.lighting || 8) * .16 + (Math.max(0,10 - Math.min((r.walk || 0.5)*2, 10))) * .26;
  if(prefs.stepFree && !r.stepFree) score -= 2.8;
  if(prefs.lit && (r.lighting || 8) < 6) score -= 1.2;
  if(prefs.avoidWalk) score -= Math.min((r.walk || 0.5), 5) * .55;
  return Math.max(0, Math.min(10, score));
}

function routeSearch(){
  const origin = $("origin").value.trim().toLowerCase();
  const dest = $("destination").value.trim().toLowerCase();

  if(!origin || !dest || origin === dest){
    toast("Enter two different valid locations.");
    return;
  }

  const matches = routesCache.filter(r => 
    (r.origin.toLowerCase() === origin && r.destination.toLowerCase() === dest) ||
    (r.origin.toLowerCase() === dest && r.destination.toLowerCase() === origin)
  );

  const prefs = {
    stepFree: $("need-stepfree").checked,
    lit: $("prefer-lit").checked,
    avoidWalk: $("avoid-walk").checked
  };

  const host = $("route-results");
  $("route-count").textContent = matches.length + " database route option(s)";

  if(!matches.length){
    host.innerHTML = '<div class="empty-state"><div class="empty-icon">⌖</div><b>No matching route found in database</b><p>Add new routes using the "Add New Route" tab.</p></div>';
    return;
  }

  const ranked = matches.map(r => ({r, score: scoreRoute(r, prefs)})).sort((a,b) => b.score - a.score);

  host.innerHTML = ranked.map(({r, score}, i) => `
    <article class="route-card ${i===0?"best":""}">
      <div>
        <div class="route-name">${esc(r.mode)} · ${esc(r.origin)} → ${esc(r.destination)}</div>
        <div class="route-meta">${Number(r.distance).toFixed(1)} km &nbsp;·&nbsp; ${Math.round(r.duration)} min &nbsp;·&nbsp; ₹${Math.round(r.fare)}</div>
      </div>
      <div>
        <div class="score-wrap">
          <div class="score">${score.toFixed(1)}<small>/10</small></div>
          <div style="flex:1">
            <div class="muted">ROUTE SUITABILITY</div>
            <div class="scorebar"><span style="width:${score*10}%"></span></div>
          </div>
        </div>
      </div>
      <div class="route-detail">
        <span>Safety <b>${(r.safety || 8).toFixed(1)}/10</b></span>
        <span>Accessibility <b>${(r.accessibility || 8).toFixed(1)}/10</b></span>
        <span>Lighting <b>${(r.lighting || 8).toFixed(1)}/10</b></span>
        <span>Walk <b>${(r.walk || 0.5).toFixed(1)} km</b></span>
        <span>Step-free <b>${r.stepFree ? "Listed" : "Not confirmed"}</b></span>
        <span>${esc(r.notes || '')}</span>
      </div>
    </article>
  `).join("");
}

function mins(t){
  const [h,m] = t.split(":").map(Number);
  return h*60+m;
}

function fmt(m){
  m = ((Math.round(m)%1440)+1440)%1440;
  return String(Math.floor(m/60)).padStart(2,"0")+":"+String(m%60).padStart(2,"0");
}

function costSearch(){
  const origin = $("cost-origin").value.trim().toLowerCase();
  const dest = $("cost-destination").value.trim().toLowerCase();
  const deadline = $("arrive-by").value;
  const budget = Number($("budget").value);

  if(!origin || !dest || !deadline || isNaN(budget)){
    toast("Check locations, arrival time and budget.");
    return;
  }

  const matches = routesCache.filter(r => 
    (r.origin.toLowerCase() === origin && r.destination.toLowerCase() === dest) ||
    (r.origin.toLowerCase() === dest && r.destination.toLowerCase() === origin)
  );

  const deadlineMin = mins(deadline);
  const items = [];

  matches.forEach(r => {
    const deps = Array.isArray(r.departures) && r.departures.length ? r.departures : ["08:00", "08:30", "09:00"];
    const validDeps = deps.map(mins).filter(t => t + r.duration <= deadlineMin).sort((a,b)=>b-a);
    if(!validDeps.length) return;

    const depart = validDeps[0];
    const leave = depart - 15;
    const score = scoreRoute(r, {lit:true});
    items.push({r, depart, leave, arrive: depart + r.duration, score, total: r.fare});
  });

  items.sort((a,b) => a.total - b.total || b.score - a.score);

  const host = $("cost-results");
  if(!items.length){
    host.innerHTML = '<div class="empty-state"><b>No matching scheduled option found</b><p>Try a later arrival deadline or budget.</p></div>';
    return;
  }

  host.innerHTML = items.map((x,i) => `
    <article class="journey-card ${i===0?"best":""}">
      <div>
        <h4>${esc(x.r.mode)} · ${esc(x.r.origin)} → ${esc(x.r.destination)}</h4>
        <p>${x.r.distance.toFixed(1)} km · ${Math.round(x.r.duration)} min travel · ${esc(x.r.notes || '')}</p>
        <div class="journey-times">
          <span>Leave home <b>${fmt(x.leave)}</b></span>
          <span>Transport departs <b>${fmt(x.depart)}</b></span>
          <span>Arrive <b>${fmt(x.arrive)}</b></span>
          <span>Suitability <b>${x.score.toFixed(1)}/10</b></span>
        </div>
      </div>
      <div class="journey-price">
        ₹${Math.round(x.total)}
        <small>ESTIMATED FARE</small>
        ${x.total <= budget ? '<small style="color:#16866b;margin-top:8px">WITHIN BUDGET</small>' : '<small style="color:#d34f55;margin-top:8px">OVER BUDGET</small>'}
      </div>
    </article>
  `).join("");
}

function renderReports(){
  const host = $("reports-list");
  if(!host) return;
  $("report-count").textContent = reportsCache.length + " report(s)";
  host.innerHTML = reportsCache.length ? reportsCache.map(r => `
    <div class="report-item">
      <div>
        <b>${esc(r.location)} · ${esc(r.type.replace("_"," "))}</b>
        <p>${esc(r.description)} · ${new Date(r.createdAt).toLocaleString()}</p>
      </div>
      <span class="report-badge">${esc((r.severity || 'medium').toUpperCase())}</span>
    </div>
  `).join("") : '<div class="empty-state"><b>No community reports yet</b><p>Submitted reports will be saved to your MongoDB database.</p></div>';
}

// Form Submissions
$("report-form").addEventListener("submit", async e => {
  e.preventDefault();
  const payload = {
    location: $("report-location").value,
    type: $("report-type").value,
    severity: $("report-severity").value,
    description: $("report-description").value
  };

  try {
    const res = await fetch('/api/reports', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(payload)
    });
    if(res.ok){
      toast("Report saved successfully!");
      e.target.reset();
      await fetchReports();
    }
  } catch(err) {
    toast("Error saving report.");
  }
});

$("add-route-form").addEventListener("submit", async e => {
  e.preventDefault();
  const deps = $("add-departures").value.split(",").map(s => s.trim()).filter(Boolean);
  const payload = {
    origin: $("add-origin").value,
    destination: $("add-destination").value,
    mode: $("add-mode").value,
    distance: Number($("add-distance").value),
    duration: Number($("add-duration").value),
    fare: Number($("add-fare").value),
    safety: Number($("add-safety").value),
    lighting: Number($("add-lighting").value),
    accessibility: Number($("add-accessibility").value),
    walk: Number($("add-walk").value),
    stepFree: $("add-stepfree").value === "true",
    departures: deps.length ? deps : ["08:00", "08:30", "09:00"],
    notes: $("add-notes").value
  };

  try {
    const res = await fetch('/api/routes', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(payload)
    });
    if(res.ok){
      toast("New route saved!");
      e.target.reset();
      await fetchRoutes();
    }
  } catch(err) {
    toast("Error saving route.");
  }
});

// Navigation
document.querySelectorAll(".nav-item").forEach(btn => btn.addEventListener("click", () => {
  document.querySelectorAll(".nav-item").forEach(x => x.classList.remove("active"));
  document.querySelectorAll(".view").forEach(x => x.classList.remove("active"));
  btn.classList.add("active");
  $("view-" + btn.dataset.view).classList.add("active");
  $("page-title").textContent = ({
    route: "Route Info",
    cost: "Cost & Departure Estimation",
    reports: "Community Reports",
    "add-route": "Add New Route"
  })[btn.dataset.view];
}));

$("find-routes").onclick = routeSearch;
$("estimate-cost").onclick = costSearch;

// Init
fetchRoutes();
fetchReports();
})();
