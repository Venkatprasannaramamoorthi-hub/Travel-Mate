# Travel Mate – Journey persistence fix

## What changed
- Added an additive Mongoose `Journey` model and `journeys` collection.
- Added `GET /api/journeys` and `POST /api/journeys`.
- Validates locations, dates, numeric limits, waiting preference and selected transport details on the server.
- The Cost and Departure Estimation form now POSTs the chosen option to the backend.
- Recent saved journey plans are loaded into the UI.
- JSON fallback persistence includes journeys when MongoDB is unavailable.

## Existing backend compatibility
The existing `Route` and `Report` schemas, collections and endpoints are retained. No new npm dependencies are required.

## Apply
Extract this ZIP over a backup copy of the existing project, replacing the files. Then run:

```powershell
npm install
$env:MONGO_URI="mongodb://127.0.0.1:27017/travel_mate"
npm start
```

Open `http://localhost:5000`, submit a Cost and Departure Estimation request, and look for the `journeys` collection in MongoDB Compass.

A successful MongoDB save is reported in the page as “Journey saved to MongoDB”. In offline fallback mode it explicitly reports local-file storage instead.
