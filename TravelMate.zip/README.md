# Travel Mate — Offline-first mobility application

Travel Mate starts with two primary interfaces:
1. **ROUTE INFO** — filters available locally stored transport options and ranks them using a transparent 0–10 score based on safety, accessibility, lighting, community activity, fare and journey duration.
2. **COST AND DEPARTURE ESTIMATION** — selects a timetable departure that can meet the requested arrival time, then calculates the recommended time to leave home using the user's access-to-stop time and early-arrival buffer. It also checks requested public amenities against imported local amenity records.

## Strict challenge constraint: no external internet or third-party APIs
- The front end makes no requests to map tiles, online geocoders, online routing services, CDNs, font hosts or external APIs.
- The map is a bundled schematic illustration, not live Leaflet/OSM mapping. It is intentionally self-contained so the map continues to render with all network connectivity disabled.
- All essential screens and data tools work from the local app and browser storage.
- The Node server has local JSON-file persistence in `data/travel-mate.json` when MongoDB is unavailable. If MongoDB is configured and reachable, it uses the existing Mongoose Route and Report collections.
- Optional LLM integration uses Ollama on `127.0.0.1` only. It is disabled unless `OLLAMA_MODEL` is configured. No cloud model is called. The local model returns a separate 0–10 assessment and short rationale; a transparent deterministic score remains the stable ranking fallback if Ollama is absent or returns invalid output. The model cannot establish live safety or predict incidents without reliable historical/contextual data.
- To use a local model, install Ollama and download the model before the challenge, then start Ollama and set `OLLAMA_MODEL` to the installed model name. For example, in PowerShell: `$env:OLLAMA_MODEL="llama3.2"` before `npm start`. Model download requires internet before the offline challenge; inference runs locally.

## Strict challenge constraint: malformed or malicious data
- JSON parsing failures, malformed CSV, oversized uploads, missing required fields, wrong data types, unexpected arrays/objects, duplicate route/report/amenity records, invalid departure times, invalid timestamps, negative or implausible numbers, invalid booleans and unsupported severity values are rejected.
- Import is validated completely before replacing the current local dataset.
- Strings are Unicode-normalized, control characters are removed, length-limited and HTML-escaped before display.
- The API validates independently of the browser; client-side checks are not treated as a security boundary.
- Express JSON bodies are limited to 1 MB. Security response headers and bounded query/result sizes are enabled.

## Important real-world data limitation
The included Chennai routes and departure times are **illustrative demo data**, not verified current timetables, live traffic, current fares, or measured safety statistics. The local departure engine calculates a leave-home time from the selected timetable, user-entered access time and buffer; it does not know real-time delays. A production launch requires permissioned/verified operator timetables, fare tables, route geometry, facility inventories and a maintained safety/community dataset to be imported into the local environment. The app intentionally labels scores as indicative and never treats missing amenity information as proof that a facility exists. It does not claim to predict crime or guarantee safety.

## Run locally
1. Install Node.js LTS.
2. Extract the project ZIP and open the extracted project root (the folder containing `package.json`) in VS Code.
3. Run `npm install` while package access is available, before the offline challenge.
4. Run `npm start`.
5. Open `http://localhost:5000`.

MongoDB is optional for local operation. To use it, set `MONGO_URI` to a MongoDB instance accessible in the local environment. Without it, the server persists data in the project's `data/` directory. For deployment, attach a persistent disk to that directory or use a managed MongoDB instance; managed services may not satisfy the no-external-network challenge rule.

## Deployment notes
This application can be deployed to a server that has Node.js and persistent storage. For a strictly isolated deployment, bundle all runtime dependencies in advance, run MongoDB and (optionally) Ollama on the same private network/host, and block outbound internet at the infrastructure layer. Do not rely on an online basemap or cloud LLM. A deployment platform with ephemeral filesystem storage will lose local JSON records on restart unless a persistent volume is attached.


## Saved journey persistence

The Cost and Departure Estimation form now saves the selected journey plan through `POST /api/journeys` and lists recent plans from `GET /api/journeys`. Each record includes origin, destination, arrival deadline, access time, early-arrival buffer, optional budget, waiting preference, and the selected transport option with departure, leave-home and estimated-arrival timestamps.

MongoDB mode stores these records in the additive `journeys` collection. Existing `Route` and `Report` schemas and collections are unchanged. If MongoDB is unavailable, journey records are persisted in the local JSON data file alongside the existing local fallback data. The UI states which storage mode accepted the record.

To verify after starting the app, submit a journey in Cost and Departure Estimation, then refresh MongoDB Compass and expand `travel_mate` → `journeys`. The UI also shows the recent saved journey history.
